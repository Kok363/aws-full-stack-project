## AWS Full-Stack Template README Images

Images in this directory are for the purposes of showing up in the README.md file
