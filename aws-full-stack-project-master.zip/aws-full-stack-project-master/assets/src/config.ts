export default {
  MAX_ATTACHMENT_SIZE: 5000000,
  apiGateway: {
    REGION: "us-east-1",
    API_URL: "https://fjngnfrqig.execute-api.us-east-1.amazonaws.com/prod",
  },
  cognito: {
    REGION: "us-east-1",
    USER_POOL_ID: "us-east-1_9zEFUKHfG",
    APP_CLIENT_ID: "q4apguuksr142bto3trnuu91e",
    IDENTITY_POOL_ID: "us-east-1:7a11df8f-43ae-4e5e-a787-1956fc01a2a8"
  }
};