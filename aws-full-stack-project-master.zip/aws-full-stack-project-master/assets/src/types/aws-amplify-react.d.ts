declare module 'aws-amplify-react';
